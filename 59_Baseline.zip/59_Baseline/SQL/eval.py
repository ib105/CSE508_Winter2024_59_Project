import mysql.connector
import pandas as pd
import numpy as np
from sqlalchemy import create_engine

# Database connection parameters
db_config = {
    'host': 'localhost',
    'user': 'root',
    'password': 'Akshay132',
    'database': 'IR'
}

# Establish a database connection
try:
    db_connection = mysql.connector.connect(**db_config)
    print("Database connection established.")
except mysql.connector.Error as err:
    print(f"Database connection error: {err}")
    exit(1)

engine_url = f"mysql+mysqlconnector://{db_config['user']}:{db_config['password']}@{db_config['host']}/{db_config['database']}"
engine = create_engine(engine_url)

# SQL queries to fetch recommendations and interactions
sql_recommendations = "SELECT Title, Bodypart FROM TrainingPrograms;"
sql_interactions = "SELECT username, BMI FROM UserDetails WHERE Hobby = 'Football';"

# Fetch data into pandas DataFrames
df_recommendations = pd.read_sql(sql_recommendations, con=engine)
df_interactions = pd.read_sql(sql_interactions, con=engine)
# Close the database connection
db_connection.close()

# Prepare to calculate metrics
metrics = {
    'user_id': [],
    'precision': [],
    'recall': [],
    'f1_score': []
}

# Calculate Precision, Recall, and F1 Score for each user
user_ids = df_recommendations['Title'].unique()
for user_id in user_ids:
    recs = df_recommendations[df_recommendations['Title'] == user_id]['Bodypart']
    relevant = df_interactions[df_interactions['username'] == user_id]['BMI']
    
    # True Positives: Recommended & Relevant
    tp = len(set(recs) & set(relevant))
    
    # Precision and Recall
    precision = tp / len(recs) if len(recs) > 0 else 0
    recall = tp / len(relevant) if len(relevant) > 0 else 0
    
    # F1 Score
    f1_score = 2 * (precision * recall) / (precision + recall) if (precision + recall) > 0 else 0
    
    # Store metrics
    metrics['user_id'].append(user_id)
    metrics['precision'].append(precision)
    metrics['recall'].append(recall)
    metrics['f1_score'].append(f1_score)

# Convert metrics to a DataFrame for easy viewing
df_metrics = pd.DataFrame(metrics)

# Displaying individual user metrics
print("Individual User Metrics:")
print(df_metrics)

# Calculate and print overall averages of the metrics
print("\nOverall Averages:")
print(f"Average Precision: {df_metrics['precision'].mean()}")
print(f"Average Recall: {df_metrics['recall'].mean()}")
print(f"Average F1 Score: {df_metrics['f1_score'].mean()}")
