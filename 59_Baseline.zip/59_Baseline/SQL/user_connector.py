import mysql.connector
import pandas as pd
from sqlalchemy import create_engine

# Specify the path to your CSV file
csv_file_path = '/Users/akshay/Desktop/IR/project/deadline 2/user_details.csv'

# Read the CSV file into a DataFrame
try:
    df_user_details = pd.read_csv(csv_file_path)
    print("CSV file read successfully.")
except Exception as e:
    print(f"Failed to read CSV file: {e}")
    sys.exit(1)

# Database connection details
db_username = 'root'  # Your MySQL username
db_password = 'Akshay132'  # Your MySQL password
db_host = 'localhost'  # Database host
db_name = 'IR'  # Your database name

# SQLAlchemy engine for MySQL connection
engine_url = f'mysql+mysqlconnector://{db_username}:{db_password}@{db_host}/{db_name}'
engine = create_engine(engine_url)

# Convert DataFrame to SQL table, replacing if it already exists
table_name = 'UserDetails'
df_user_details.to_sql(name=table_name, con=engine, if_exists='replace', index=False)

print(f"DataFrame has been successfully stored as the table '{table_name}' in the database '{db_name}'.")
