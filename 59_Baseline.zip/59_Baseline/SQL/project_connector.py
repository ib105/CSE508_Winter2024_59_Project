import mysql.connector
import pandas as pd
import numpy as np
import sys

# Ensure the dataset path is correct.
dataset_path = '/Users/akshay/Desktop/IR/project/deadline 2/TrainingDataset.csv'

# Try reading the CSV file.
try:
    data = pd.read_csv(dataset_path, encoding='ISO-8859-1', on_bad_lines='skip')
except Exception as e:
    print(f"An error occurred while reading the CSV file: {e}")
    sys.exit(1)

# Establish a database connection.
try:
    db_connection = mysql.connector.connect(
      host="localhost",
      user="root",
      password="Akshay132",
      database="IR"
    )
except mysql.connector.Error as err:
    print(f"Error: {err}")
    sys.exit(1)

cursor = db_connection.cursor()

# Function to insert data into the TrainingPrograms table, with nan handling
def insert_training_program(title, desc, exercise_type, body_part, equipment, level, rating, rating_desc):
    # Explicitly convert pandas nan to None for all fields
    values = [title, desc, exercise_type, body_part, equipment, level,
              None if pd.isna(rating) else rating,
              None if pd.isna(rating_desc) else rating_desc]
    values = [None if pd.isna(value) else value for value in values]
    sql = """INSERT INTO TrainingPrograms (Title, `Desc`, Type, BodyPart, Equipment, Level, Rating, RatingDesc) 
             VALUES (%s, %s, %s, %s, %s, %s, %s, %s)"""
    try:
        cursor.execute(sql, values)
        db_connection.commit()
    except mysql.connector.Error as e:
        print(f"Failed to insert data into the database: {e}")

# Iterate through the DataFrame and insert each row into the database.
for index, row in data.iterrows():
    insert_training_program(row['Title'], row['Desc'], row['Type'], row['BodyPart'],
                            row['Equipment'], row['Level'], row['Rating'], row['RatingDesc'])

# Close the connection.
cursor.close()
db_connection.close()
